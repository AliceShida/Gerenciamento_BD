SELECT * FROM unidata.v_matriculas_alunos;

ALTER TABLE v_matriculas_alunos
ADD COLUMN disciplina

 CREATE OR REPLACE VIEW v_matriculas_alunos AS
SELECT 
alunos AS nome,
disciplinas AS curso,
matriculas AS semestre
FROM
	v_matriculas_alunos;
